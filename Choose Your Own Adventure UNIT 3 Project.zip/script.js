document.addEventListener("DOMContentLoaded", (event) => {
//Create variables and connect them to HTML using document.querySelector

let openScene = document.querySelector(".openScene");
let continue = document.querySelector(".Continue");
let start = document.querySelector(".start");
let contextAScene = document.querySelector(".context-A-Scene");
let optionAScene = document.querySelector(".option-A-Scene");
let shoot = document.querySelector(".Shoot");
let dont = document.querySelector(".Dont");
let optionA1 = document.querySelector(".optionA1");
let Return = document.querySelector(".Return");
let optionA2 = document.querySelector(".optionA2");
let Click = document.querySelector(".Click");
let contextBScene = document.querySelector(".context-B-Scene");
let optionBScene = document.querySelector(".option-B-Scene");


let optionB1 = document.querySelector(".optionB1");
let Reurn= document.querySelector(".Reurn");
let optionB2 = document.querySelector(".optionB2");

let contextCScene = document.querySelector(".context-C-Scene");
let optionCScene = document.querySelector(".option-C-Scene");

let optionC1 = document.querySelector(".optionC1");
let Retrn= document.querySelector(".Retrn");
let optionC2 = document.querySelector(".optionC2");

//Create click, funtions using addEventListener //

openScene.addEventListener("click", function (){

})



































});